package br.unipar.backend.minhaapi.controller;

import br.unipar.backend.minhaapi.model.Usuario;
import org.apache.coyote.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/usuario")

public class UsuarioController {

    List<Usuario> bancodados = new ArrayList<>();

    @GetMapping("/hello/{nome}")
    public String helloWorld(@PathVariable  String nome) {
        return "Hello World, "+ nome;
    }
    @GetMapping("/hello2")
    public String HelloWorld2(@RequestParam(required = false) String nome){
        if (nome == null) {
            return "Hello World";
        }else {
            return "Hello World, " +nome;
        }
    }

    @GetMapping("/listar-todos")
    public ResponseEntity<List<Usuario>> ListarTodos(){
        return ResponseEntity.ok(bancodados);
    }

    @PostMapping("/gravar")
    public String gravarUsuario(@RequestBody Usuario usuario) {
        if (usuario == null){
            return "Hello World, Stranger!";
        }else {
            bancodados.add(usuario); //simulando uma insercao no banco de dados
            return "Hello World, "+ usuario.getNome();
        }
    }

    @PutMapping("/editar/{index}") //editar
    public ResponseEntity<Usuario> helloWorld4(@PathVariable int index,
                                      @RequestBody(required = false) Usuario usuario){
        if (usuario == null){
            return ResponseEntity.noContent().build(); //sem conteudo
        } else{
            Usuario u = new Usuario(); //Simulando que esse usario vemda base
            u.setId(usuario.getId());
            u.setNome(usuario.getNome());
            u.setEmail(usuario.getEmail());

            bancodados.set(index, u);

            return ResponseEntity.ok(u);
        }
    }

    @DeleteMapping("deletar/{index}")
    public ResponseEntity deletarUsuario(@PathVariable int index){
        bancodados.remove(index);
        return ResponseEntity.ok("Usuario"+ index + "deletado com sucesso!");
    }

}
