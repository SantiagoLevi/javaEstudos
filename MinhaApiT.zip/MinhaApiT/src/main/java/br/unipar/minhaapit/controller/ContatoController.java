package br.unipar.minhaapit.controller;

import br.unipar.minhaapit.model.Contato;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/contatos")
public class ContatoController {

    private List<Contato> contatos = new ArrayList<>();

    @GetMapping("/completo")
    public ResponseEntity<List<Contato>> listar() {

        return ResponseEntity.ok(contatos);

    }


    @GetMapping("/id/{id}")
    public ResponseEntity<Contato> listarId(@PathVariable Long id) {

        for (Contato contato : contatos) {
            if (contato.getId().equals(id)) {
                return ResponseEntity.ok(contato);
            }
        }
        return ResponseEntity.notFound().build();

    }


    @PostMapping
    public ResponseEntity<Contato> cadastrarContato(@RequestBody Contato contato) {
        contatos.add(contato);
        return ResponseEntity.ok(contato);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Contato> atualizarContato(@PathVariable Long id,
                                                    @RequestBody Contato contatoAtualizado) {
        for (Contato contato : contatos) {

            if (contato.getId().equals(id)) {

                contato.setNome(contatoAtualizado.getNome());
                contato.setTelefone(contatoAtualizado.getTelefone());
                contato.setEmail(contatoAtualizado.getEmail());
                contato.setCidade(contatoAtualizado.getCidade());

                return ResponseEntity.ok(contato);
            }
        }
        return ResponseEntity.notFound().build();

    }

    @DeleteMapping("/deletar/{id}")
    public ResponseEntity deletarContato(@PathVariable Long id) {

        for (Contato contato : contatos) {

            if (contato.getId().equals(id)) {

                contatos.remove(contato);
                return ResponseEntity.ok("Contato " + id + " deletado com sucesso!");

            }
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/filtro")
    public ResponseEntity<List<Contato>> listarFiltros(@RequestParam(required = false) String nome,
                                                       @RequestParam(required = false) String cidade,
                                                       @RequestParam(required = false) String email) {
        List<Contato> resultado = new ArrayList<>();

        for (Contato contato : contatos) {

            boolean adicionar = true;

            if (nome != null) {
                if (!contato.getNome().equals(nome)) {
                    adicionar = false;
                }
            }

            if (cidade != null) {
                if (!contato.getCidade().equals(cidade)) {
                    adicionar = false;
                }
            }

            if (email != null) {
                if (!contato.getEmail().equals(email)) {
                    adicionar = false;
                }
            }

            if (adicionar) {
                resultado.add(contato);
            }
        }

        return ResponseEntity.ok(resultado);


    }

}
