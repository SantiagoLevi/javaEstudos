package br.unipar.minhaapit.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Contato {

    private Long id;

    private String nome;

    private String telefone;

    private String email;

    private String cidade;

}
