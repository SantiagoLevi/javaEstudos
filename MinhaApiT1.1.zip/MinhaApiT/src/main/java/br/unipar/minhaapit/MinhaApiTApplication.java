package br.unipar.minhaapit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhaApiTApplication {

    public static void main(String[] args) {
        SpringApplication.run(MinhaApiTApplication.class, args);
    }
    
}
