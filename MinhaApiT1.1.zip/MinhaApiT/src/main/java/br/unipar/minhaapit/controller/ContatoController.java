package br.unipar.minhaapit.controller;

import br.unipar.minhaapit.model.Contato;
import br.unipar.minhaapit.repository.ContatoRepository;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/contatos")
public class ContatoController {

    private final ContatoRepository repository;

    public ContatoController(ContatoRepository repository) {
        this.repository = repository;
    }



    @GetMapping("/completo")
    public ResponseEntity<List<Contato>> listar() {

        return ResponseEntity.ok(repository.findAll());

    }


    @GetMapping("/id/{id}")
    public ResponseEntity<Contato> listarId(@PathVariable Long id) {

        Optional<Contato> contato = repository.findById(id);

        if (contato.isPresent()) {
            return ResponseEntity.ok(contato.get());
        }

        return ResponseEntity.notFound().build();

    }


    @PostMapping
    public ResponseEntity<Contato> cadastrarContato(@RequestBody Contato contato) {

        contato.setId(null);

        Contato novoContato = repository.save(contato);

        return ResponseEntity.status(201).body(novoContato);

    }

    @PutMapping("/{id}")
    public ResponseEntity<Contato> atualizarContato(@PathVariable Long id,
                                                    @RequestBody Contato contatoAtualizado) {

        Optional<Contato> encontrado = repository.findById(id);

        if (encontrado.isPresent()) {

            Contato contato = encontrado.get();

            contato.setNome(contatoAtualizado.getNome());
            contato.setTelefone(contatoAtualizado.getTelefone());
            contato.setEmail(contatoAtualizado.getEmail());
            contato.setCidade(contatoAtualizado.getCidade());

            repository.save(contato);

            return ResponseEntity.ok(contato);
        }

        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/deletar/{id}")
        public ResponseEntity deletarContato (@PathVariable Long id){

            Optional<Contato> encontrado = repository.findById(id);

            if (encontrado.isPresent()) {

                repository.delete(encontrado.get());

                return ResponseEntity.ok("Contato " + id + " deletado com sucesso!");

            }

            return ResponseEntity.notFound().build();

        }

    @GetMapping("/filtro")
    public ResponseEntity<List<Contato>> listarFiltros(@RequestParam(required = false) String nome,
                                                       @RequestParam(required = false) String cidade,
                                                       @RequestParam(required = false) String email) {
        Contato exemplo = new Contato();

        exemplo.setNome(nome);
        exemplo.setCidade(cidade);
        exemplo.setEmail(email);

        ExampleMatcher matcher = ExampleMatcher.matchingAll()
                .withIgnoreNullValues();

        Example<Contato> filtro = Example.of(exemplo, matcher);

        return ResponseEntity.ok(repository.findAll(filtro));
    }


    }


