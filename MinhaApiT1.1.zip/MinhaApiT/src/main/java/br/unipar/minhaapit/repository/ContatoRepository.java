package br.unipar.minhaapit.repository;


import br.unipar.minhaapit.model.Contato;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContatoRepository
        extends JpaRepository<Contato, Long> {

}
