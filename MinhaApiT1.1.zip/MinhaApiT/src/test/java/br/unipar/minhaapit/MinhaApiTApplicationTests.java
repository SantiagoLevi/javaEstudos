package br.unipar.minhaapit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinhaApiTApplicationTests {

    @Test
    void contextLoads() {
    }

}
